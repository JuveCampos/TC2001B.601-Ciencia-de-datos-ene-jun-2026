#Librerias
library(tidyverse)
library(ggplot2)
#Cargamos datos
catedos = read.csv("datos_problemario/cat_edos.csv")
catmun = read.csv("datos_problemario/cat_mun.csv")
indest = read.csv("datos_problemario/indicadores_estatales.csv")
indmun = read.csv("datos_problemario/indicadores_municipales.csv")
metest = read.csv("datos_problemario/metadatos_estatales.csv")
metmun = read.csv("datos_problemario/metadatos_municipales.csv")

#Ejercicio 1: filter + select ====

#Filtramos por año y indicador
# Excluimos cve_ent “00”, “33”, “34” y “99”
ej1 = indest %>% 
  filter(no == 921, year == 2022) %>%
  filter(cve_ent != "00") %>% 
  filter(cve_ent != "33") %>% 
  filter(cve_ent != "34") %>% 
  filter(cve_ent != "99") %>% 
  #Seleciionamos los que nos importa y traemos los nombres de los estados
  select(cve_ent, valor) %>%
  left_join(catedos, by = "cve_ent") %>% 
  #los ordenamos
  arrange(desc(valor)) 

head(ej1,3)

#los 3 estados con mayor pobreza en 2022 son chiapas, guerrero y oaxaca


#Ejercicio 2: arrange + slice ====
# filtramos para Esperanza de Vida 2022
ej2 = indest %>% 
  filter(no == 54, year == 2020) %>% 
  filter(cve_ent != "00") %>% 
  filter(cve_ent != "33") %>% 
  filter(cve_ent != "34") %>% 
  filter(cve_ent != "99")%>%
  left_join(catedos, by = "cve_ent") %>% 
  select(entidad, valor)

# Obtenemos Top 5 y Bottom 5
top_5_ev = ej2 %>% 
  arrange(desc(valor)) %>% 
  head(5)

bottom_5_ev = ej2 %>% 
  arrange(valor) %>% 
  head(5)
#Calculamos la diferencia
diferencia = max(ej2$valor) - min(ej2$valor)

print(top_5_ev)
print(bottom_5_ev)
print(paste("La diferencia es de:", diferencia, "años"))         
#[1] "La diferencia es de: 7.33815369 años"

#Ejercicio 3: mutate ====
indest
ej3 = indest %>% 
  #Filtro de indicador, años y estados
  filter(no == 98, year %in% c(2005, 2020)) %>% 
  filter(!cve_ent %in% c("00", "33", "34", "99")) %>%
  #me quedo solo con cve_ent, year y valor
  select(cve_ent, year, valor) %>% 
  #Usamos la función pivot_wider() con estos argumentos names_from = year
  #para que los años se conviertan en los títulos de las columnas
  #values_from = valor: para que los datos numéricos llenen esas columnas.
  pivot_wider(names_from = year, values_from = valor) %>% 
  #Traemos los nombres de los estados
  left_join(catedos, by = "cve_ent") %>% 
  
  
  mutate(
    cambio_abs = `2020` - `2005`,
    cambio_pct = ((cambio_abs)/`2005`)*100
    ) %>% 
  #ordenamos para ver quien crecio mas
  arrange(desc(cambio_pct))
# Extraemos el valor de la fila 1
estado_ganador = ej3$entidad[1]
print(paste("El estado que tuvo el mayor crecimiento porcentual en adopción de celulares fue ", estado_ganador ))    
cambio_celulares = ej3
cambio_celulares

#El estado que tuvo el mayor crecimiento porcentual en adopción de celulares fue Durango

#Ejercicio 4: group_by + summarise ====
ej4 = indest %>% 
  filter(no == 156) %>% 
  filter(cve_ent == 00) %>% 
  #creamos la columna decada y el calculo para hacerla
  mutate(
    decada = (year %/% 10) * 10
  ) %>% 
  #Agrupamos por decada
  group_by(decada) %>% 
  #calculamos el promedio y desviación estandar con na.rm, si falta el dato de 
  #algún año lo ignora
  summarise(
    promedio = mean(valor, na.rm = TRUE),
    desv_est = sd(valor, na.rm = TRUE)
  ) %>% 
  #Ordenar para ver cuál es el mayor
  arrange(desc(promedio))
vehiculos_decada=ej4
vehiculos_decada

#La década en que se registra el mayor promedio de vehículos por 1000 habitantes es 2020 con un promedio de 420

#Ejercicio 5: geom_line ====


ej5 = indest %>% 
  #filtramos la mortalidad por diabetes de 2000 a 2023
  #para cinco estados: Chiapas, Tabasco, Puebla, Nuevo León y Sonora
  filter(no == 36, year >= 2000) %>%
  left_join(catedos, by = "cve_ent") %>% 
  filter(entidad %in% c('Chiapas', 'Tabasco', 'Puebla', 'Nuevo León', 'Sonora'))
  
#grafica con líneas de colores, título, etiquetas de ejes, tema limpio con 2 modificaciones para ajustar el texto
grafica_diabetes = ggplot(ej5, aes(x = year, 
                                            y = valor, color = entidad))+
  geom_line() + 
  theme_minimal() + 
  labs(title = "Mortalidad por diabetes por 100k de 2000 a 2023 para
       Chiapas, Tabasco, Puebla, Nuevo León y Sonora", x = "Año", 
       y = "Muertes por cada 100k", color = "Estado",
       caption = "Datos tomados de https://github.com/JuveCampos/TC2001B.601-Ciencia-de-datos-ene-jun-2026/blob/main/04_TAREAS/TAREA%2001.zip", 
  )+
  theme(plot.title = element_text(hjust = 0.5),
        plot.caption = element_text(hjust= 0.1)
        )
print(grafica_diabetes)

#Ejercicio 6: geom_col ====
ej6 = indest %>% 
  filter(no == 569, year == 2024) %>%
  filter(!cve_ent %in% c("00", "33", "34", "99", 0)) %>%
  left_join(catedos, by = "cve_ent")

#verificación rapida
ej6_verificacion <- ej6 %>% 
  arrange(desc(valor))

#usamos reorder() dentro de aes() para ordenar las barras
grafica_satisfaccion = ggplot(ej6, aes(x = reorder(entidad, valor),
                                       y = valor,
                                       fill = valor)) +
  #Creamos las barras
  geom_col() +
  #agregamos coord_flip() para que las barras se muestren horizontales
  coord_flip() + 
 # Coloreamos las barras por valor usando scale_fill_gradient() degradado de color
  scale_fill_gradient(low = "#481AFF", high = "#FCFF40") +
  
  labs(title = "Satisfacción con la vida por estado (2024)", 
          x = "Estado", 
          y = "Puntaje (0-10)", 
          fill = "Valor") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

#Respuesta: Chihuahua

#Ejercicio 7: geom_point (scatter plot) ====
# generamos dos filtros para despues unir con una función left_join()
pib = indest %>% 
  filter(no == 1266, year == 2020) %>% 
  select(cve_ent, pib = valor) # Le ponemos nombre a la columna

# Pieza B: Solo Fecundidad 2020
fec = indest %>% 
  filter(no == 40, year == 2020) %>% 
  select(cve_ent, fecundidad = valor)

pib_fecundidad = pib %>% 
  left_join(fec, by = "cve_ent")

grafica_pib_fecundidad = ggplot(pib_fecundidad, aes(x = pib,
                                                    y = fecundidad)) +
                                  #Utilizamos geopoint
                                  geom_point()

#Respuesta: Entre una fecundidad adolescente mayor un menor PIB per cápita o entre un mayor PIB per cápita la fecundidad adolescente baja

#Ejercicio 8: Personalización de gráficas ====

ej5 = indest %>% 
  #filtramos la mortalidad por diabetes de 2000 a 2023
  #para cinco estados: Chiapas, Tabasco, Puebla, Nuevo León y Sonora
  filter(no == 36, year >= 2000) %>%
  left_join(catedos, by = "cve_ent") %>% 
  filter(entidad %in% c('Chiapas', 'Tabasco', 'Puebla', 'Nuevo León', 'Sonora'))

#ponemos los colores manualmente
colores_estados =  c("Chiapas" = "darkgreen", 
                     "Tabasco" = "blue", 
                     "Puebla" = "brown", 
                     "Nuevo León" = "grey", 
                     "Sonora" = "darkblue")

#grafica con líneas de colores, título, etiquetas de ejes, tema limpio con 2 modificaciones para ajustar el texto
grafica_diabetes_final = ggplot(ej5, aes(x = year, 
                                   y = valor, color = entidad))+
  geom_line() + 
  theme_minimal() + 
  labs(title = "Mortalidad por diabetes por 100k de 2000 a 2023 para
       Chiapas, Tabasco, Puebla, Nuevo León y Sonora", 
       x = "Año", 
       y = "Muertes por cada 100k", 
       color = "Estado", 
       subtitle = "Datos tomados de http://www.beta.inegi.org.mx/proyectos/registros/vitales/mortalidad/default.html",
       caption = "De Santiago Pérez Reyes", 
  )+
  # Agregamos la escala de colores manual
  scale_color_manual(values = colores_estados) +
  
  # ajuste de ejes con scale_y_continuous() para que inicie en 0 y le damos un pequeño margen superior
  scale_y_continuous(limits = c(0, NA), expand = expansion(c(0, 0.1))) +
  
  theme(
        plot.caption = element_text(hjust= 0.1)
  )
print(grafica_diabetes)
  

#Ejercicio 9: facet_wrap ====

ej9 = indest %>% 
  filter(no == 950, year >=2002, year <=2024) %>% 
  left_join(catedos, by = "cve_ent") %>% 
  filter(entidad %in% c('Tabasco', 'Chihuahua',
                        'Jalisco', 'Yucatán',
                        'Ciudad de México',
                        'Baja California'))

grafica_lluvia = ggplot(ej9, aes(x = year, 
                                 y = valor)) +
  geom_line() +
  #geom_smooth(method = "lm") para ver la tendencia.
  geom_smooth(method = "lm") + 
  #facet_wrap permite que cada panel tenga su propia escala.
  facet_wrap(~entidad, scales = "free_y")

#Ejercicio 10: _join de dos indicadores ====
#creamos 2 tablas para poder filtrar lo pedido
hom = indest %>% 
  filter(no == 173, year == 2022) %>% 
  select(cve_ent, year, valor_hom = valor)

scv = indest %>% 
  filter(no == 569, year == 2022) %>% 
  select(cve_ent, year, valor_scv = valor)

#las juntamos
unidos = hom %>% 
  inner_join(scv, by = c("cve_ent", "year"))

grafica_violencia_satisfaccion = ggplot(unidos, aes(x = valor_hom, 
                                                    y = valor_scv)) +
  geom_point()

#esta raro o creo no me sailo pero hay un estado que si tiene un alto nivel de homicidios pero esta arriba es pero viendo los demas resultados diria que no es algo que importe porque los otros estados tienen baja violencia y no tienen alta satisfacción y unos que si tienen alta asi que no importa

#Ejercicio 11: left_join con metadatos ====

#Unimos la base estatal con los metadatos (por la columna no)
indicadores_salud = indest %>% 
  left_join(metest, by = "no") %>% 
  group_by(indicador, umedida) %>% 
  summarise(n_registros = n())

indicadores_salud

#Ejercicio 12: Join con datos municipales ====
#saber el año mas reciente
indmun %>% 
  filter(Clave.de.indicador == 138) %>% 
  count(Año)

ej12 = indmun %>% 
  filter(Clave.de.indicador == 138, Año == 2019) %>% 
  #filtramos para que solo nos salga de la zona metropolitana de monterrey
  filter(Nombre.de.la.metrópoli == "Monterrey") %>% 
  #filtramos las solicitadas
  filter(Municipio %in% c('Apodaca', 'Cadereyta Jiménez'
                           , 'El Carmen', 'García',
                           'San Pedro Garza García',
                           'General Escobedo', 'Guadalupe',
                           'Juárez', 'Monterrey',
                           'Salinas Victoria',
                           'San Nicolás de los Garza',
                           'Santa Catarina', 'Santiago'))

grafica_fecundidad_mty = ggplot(ej12, aes(x = str_wrap(Municipio, width = 10), #str_wrap porque se veian amontonados los nombres
                                          y = Valor)) +
  geom_col() +
  labs(title = "Fecundidad adolescente 2019",
       subtitle = "Monterrey", 
       x = "Municipio")

names(indmun)

#Ejercicio 13: pivot_wider ====
celulares_ancho = indest %>% 
  filter(no == 98) %>% 
  filter(!cve_ent %in% c("00", "33", "34", "99")) %>%
  #para Incluir nombres de estado 
  left_join(catedos, by = "cve_ent") %>% 
  filter(year %in% c(2000, 2005, 2010, 2015, 2020)) %>% 
  select(entidad, year, valor) %>% 
  #Creamos tabla ancha donde filas = estados y columnas = años
  pivot_wider(names_from = year, values_from = valor)
  
celulares_ancho

#Ejercicio 14: pivot_longer ====

celulares_largo = celulares_ancho %>% 
  pivot_longer(cols = -c(entidad),
               names_to = "year", values_to = "valor") %>% 
  mutate(year = as.numeric(year))

#Ejercicio 15: pivot + ggplot – Dashboard ambiental ====
ej15 = indest %>% 
  filter(no %in% c(564, 950, 628)) %>% #escogi esta forma de filtrar los indicadores creo que esta bien no?
  filter(cve_ent == 9) %>% #escogo CDMX
  left_join(metest, by = "no") #uno con el nombre del indicador

grafica_ambiental = ggplot(ej15, aes(x = year, 
                                     y = valor)) +
  geom_line() +
  facet_wrap(~indicador, scales = "free") + #los separo en indicador y con scales = "free" para que respeta las iferencias de unidades y los años disponible.
  labs(title = "Ciudad de México")

grafica_ambiental

# Ejercicio 16: Use sus propios datos. ====
#leemos y guardamos en museos el directorio de museos de mexico
museos = read.csv("datos_problemario/data-2026-03-25.csv")

#El obj es hacer una grafica de col que muestre cuantos
#museos hay por tematica
colnames(museos)

ej16 = museos %>%
  #seleccionamos la columna que queremos
  select(museo_tematica_n1) %>% 
  #quitamos vacios
  filter(!is.na(museo_tematica_n1), 
         museo_tematica_n1 != "") 

final = ggplot(ej16, aes(x=museo_tematica_n1)) +
  geom_bar() + 
  #poner como label cuántos museos hay por categoría con count y after-stat(count) este le dice que cuando termine de contar use ese número final como la etiqueta (label) del texto. 
  geom_text(stat = "count", 
            aes(label = after_stat(count)),
            vjust = -0.5) + 
  theme_minimal() +
  labs(title = "Museos por tematica de México 2025",
       caption = "Elaboración propia con datos de Plataforma Nacional de Datos Abiertos",
       x = "\nTematica", y = "Cantidad\n") + 
  theme(plot.caption = element_text(hjust= 0.1)
  )

final